"""
Tests for common code (for when we implement IPv4 as well)
"""
