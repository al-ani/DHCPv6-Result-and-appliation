"""
Tests for common server components
"""
