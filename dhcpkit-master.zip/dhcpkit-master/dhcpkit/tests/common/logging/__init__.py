"""
Test whether the common logging functions work as intended
"""
