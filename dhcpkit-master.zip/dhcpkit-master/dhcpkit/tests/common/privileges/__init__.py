"""
Tests for common privileges code
"""
