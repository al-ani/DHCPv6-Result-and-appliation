"""
Tests for generic utility functions go here
"""
