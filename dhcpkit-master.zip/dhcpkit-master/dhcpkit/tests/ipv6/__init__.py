"""
Tests for the IPv6 DHCPv6 implementation go here
"""
