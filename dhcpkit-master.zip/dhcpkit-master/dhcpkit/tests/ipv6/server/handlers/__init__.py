"""
Tests for server handlers
"""
