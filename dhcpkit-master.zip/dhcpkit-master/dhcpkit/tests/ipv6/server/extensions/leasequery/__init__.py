"""
Tests for IPv6 server leasequery extensions
"""
