"""
Tests for message types go here
"""
