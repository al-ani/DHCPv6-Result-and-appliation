"""
Tests for extensions to the base DHCPv6 protocol
"""
