"""
Tests for the Leasequery extension
"""
