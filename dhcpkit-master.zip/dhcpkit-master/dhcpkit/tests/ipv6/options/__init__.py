"""
All the different options are tested here
"""
