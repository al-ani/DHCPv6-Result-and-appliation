"""
Common logging related functionality
"""
