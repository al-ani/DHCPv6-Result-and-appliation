"""
Common components that might be usable for both an IPv4 and an IPv6 server
"""
