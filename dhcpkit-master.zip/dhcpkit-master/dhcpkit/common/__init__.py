"""
Common components that might be usable for both IPv4 and IPv6
"""
