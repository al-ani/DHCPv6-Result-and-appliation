"""
Factory for the implementation of a TCP listener on a unicast address of a local network interface
"""
