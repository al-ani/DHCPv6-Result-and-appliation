"""
Factory for the implementation of a listener on a unicast address of a local network interface
"""
