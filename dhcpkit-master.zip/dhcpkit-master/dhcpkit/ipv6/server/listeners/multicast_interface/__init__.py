"""
Implementation of a listener on a local multicast network interface
"""
