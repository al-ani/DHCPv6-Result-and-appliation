"""
Implementation of DUIDs in the configuration, used for example to configure the server-id.
"""
