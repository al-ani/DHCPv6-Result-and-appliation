"""
Configuration section for EnterpriseDUID
"""
