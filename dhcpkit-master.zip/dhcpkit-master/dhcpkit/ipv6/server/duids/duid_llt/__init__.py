"""
Configuration section for LinkLayerTimeDUID
"""
