"""
Configuration section for LinkLayerDUID
"""
