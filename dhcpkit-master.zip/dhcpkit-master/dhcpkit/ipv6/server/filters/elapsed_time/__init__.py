"""
Filtering on the elapsed time field in the request
"""
