"""
Filtering on link-address subnet
"""
