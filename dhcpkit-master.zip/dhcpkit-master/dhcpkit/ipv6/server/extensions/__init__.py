"""
Extensions to the basic DHCPv6 server
"""
