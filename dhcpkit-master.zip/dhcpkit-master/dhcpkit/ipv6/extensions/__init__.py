"""
Module containing extensions to the basic DHCPv6 RFC.
"""
