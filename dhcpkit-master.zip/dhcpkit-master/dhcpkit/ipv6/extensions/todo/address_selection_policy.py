# http://www.iana.org/go/rfc7078

OPTION_ADDRSEL = 84
OPTION_ADDRSEL_TABLE = 85
