# http://www.iana.org/go/rfc6731

OPTION_RDNSS_SELECTION = 74
