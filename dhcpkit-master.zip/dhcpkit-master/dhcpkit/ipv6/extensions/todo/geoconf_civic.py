# http://www.iana.org/go/rfc4776

OPTION_GEOCONF_CIVIC = 36
