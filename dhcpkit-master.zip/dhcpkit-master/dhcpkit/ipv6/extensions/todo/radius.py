# http://www.iana.org/go/rfc7037

OPTION_RADIUS = 81
