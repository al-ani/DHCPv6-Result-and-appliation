# http://www.iana.org/go/draft-ietf-softwire-4rd-10

OPTION_4RD = 97
OPTION_4RD_MAP_RULE = 98
OPTION_4RD_NON_MAP_RULE = 99
