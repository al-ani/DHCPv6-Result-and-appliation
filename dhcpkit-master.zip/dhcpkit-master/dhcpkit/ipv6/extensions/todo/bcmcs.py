# http://www.iana.org/go/rfc4280

OPTION_BCMCS_SERVER_D = 33
OPTION_BCMCS_SERVER_A = 34
