# http://www.iana.org/go/rfc5192

OPTION_PANA_AGENT = 40
