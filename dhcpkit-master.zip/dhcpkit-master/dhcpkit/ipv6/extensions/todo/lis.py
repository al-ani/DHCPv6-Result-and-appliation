# http://www.iana.org/go/rfc5986

OPTION_V6_ACCESS_DOMAIN = 57
