# http://www.iana.org/go/rfc6977

OPTION_LINK_ADDRESS = 80
