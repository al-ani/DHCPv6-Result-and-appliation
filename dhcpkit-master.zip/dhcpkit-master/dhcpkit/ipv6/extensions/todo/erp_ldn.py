# http://www.iana.org/go/rfc6440

OPTION_ERP_LOCAL_DOMAIN_NAME = 65
