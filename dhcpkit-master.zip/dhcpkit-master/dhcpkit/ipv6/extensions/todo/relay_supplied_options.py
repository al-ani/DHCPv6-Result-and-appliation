# http://www.iana.org/go/rfc6422

OPTION_RSOO = 66
