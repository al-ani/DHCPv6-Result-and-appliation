# http://www.iana.org/go/rfc5417

OPTION_CAPWAP_AC_V6 = 52
