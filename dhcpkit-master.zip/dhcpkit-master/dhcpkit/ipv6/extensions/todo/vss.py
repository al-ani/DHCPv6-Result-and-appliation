# http://www.iana.org/go/rfc6607

OPTION_VSS = 68
