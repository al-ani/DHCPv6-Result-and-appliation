# http://www.iana.org/go/rfc4242

OPTION_INFORMATION_REFRESH_TIME = 32
