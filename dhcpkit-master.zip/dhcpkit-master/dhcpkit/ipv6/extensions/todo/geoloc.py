# http://www.iana.org/go/rfc6225

OPTION_GEOLOCATION = 63
