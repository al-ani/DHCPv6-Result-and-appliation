# http://www.iana.org/go/rfc6153

OPTION_IPv6_ADDRESS_ANDSF = 143
