# http://www.iana.org/go/rfc6011

OPTION_SIP_UA_CS_LIST = 58
