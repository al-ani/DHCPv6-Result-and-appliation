"""
DHCPv6 client related code
"""
