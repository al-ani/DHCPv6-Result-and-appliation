Changes per version
===================

.. include:: ../CHANGELOG.rst
