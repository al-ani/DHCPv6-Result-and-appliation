dhcpkit\.ipv6\.server\.extensions\.leasequery\.config module
============================================================

.. automodule:: dhcpkit.ipv6.server.extensions.leasequery.config
    :members:
    :undoc-members:
    :show-inheritance:
