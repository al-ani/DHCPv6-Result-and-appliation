dhcpkit\.ipv6\.server\.handlers\.rapid\_commit module
=====================================================

.. automodule:: dhcpkit.ipv6.server.handlers.rapid_commit
    :members:
    :undoc-members:
    :show-inheritance:
