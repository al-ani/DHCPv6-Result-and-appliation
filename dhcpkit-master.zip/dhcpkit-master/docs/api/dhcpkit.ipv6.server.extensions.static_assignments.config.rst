dhcpkit\.ipv6\.server\.extensions\.static\_assignments\.config module
=====================================================================

.. automodule:: dhcpkit.ipv6.server.extensions.static_assignments.config
    :members:
    :undoc-members:
    :show-inheritance:
