dhcpkit\.ipv6\.server\.filters\.elapsed\_time\.config module
============================================================

.. automodule:: dhcpkit.ipv6.server.filters.elapsed_time.config
    :members:
    :undoc-members:
    :show-inheritance:
