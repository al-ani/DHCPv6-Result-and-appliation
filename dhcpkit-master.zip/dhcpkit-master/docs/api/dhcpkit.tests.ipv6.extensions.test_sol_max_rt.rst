dhcpkit\.tests\.ipv6\.extensions\.test\_sol\_max\_rt module
===========================================================

.. automodule:: dhcpkit.tests.ipv6.extensions.test_sol_max_rt
    :members:
    :undoc-members:
    :show-inheritance:
