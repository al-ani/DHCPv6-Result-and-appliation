dhcpkit\.ipv6\.server\.extensions\.sol\_max\_rt package
=======================================================

.. automodule:: dhcpkit.ipv6.server.extensions.sol_max_rt
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   dhcpkit.ipv6.server.extensions.sol_max_rt.config

