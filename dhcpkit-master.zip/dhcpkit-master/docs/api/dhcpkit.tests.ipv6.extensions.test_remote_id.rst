dhcpkit\.tests\.ipv6\.extensions\.test\_remote\_id module
=========================================================

.. automodule:: dhcpkit.tests.ipv6.extensions.test_remote_id
    :members:
    :undoc-members:
    :show-inheritance:
