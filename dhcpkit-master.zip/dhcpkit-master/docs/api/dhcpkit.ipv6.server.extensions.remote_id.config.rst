dhcpkit\.ipv6\.server\.extensions\.remote\_id\.config module
============================================================

.. automodule:: dhcpkit.ipv6.server.extensions.remote_id.config
    :members:
    :undoc-members:
    :show-inheritance:
