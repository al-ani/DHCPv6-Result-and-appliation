dhcpkit\.tests\.ipv6\.extensions package
========================================

.. automodule:: dhcpkit.tests.ipv6.extensions
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    dhcpkit.tests.ipv6.extensions.leasequery

Submodules
----------

.. toctree::

   dhcpkit.tests.ipv6.extensions.test_bulk_leasequery
   dhcpkit.tests.ipv6.extensions.test_client_fqdn
   dhcpkit.tests.ipv6.extensions.test_dns
   dhcpkit.tests.ipv6.extensions.test_dslite
   dhcpkit.tests.ipv6.extensions.test_echo_request_option
   dhcpkit.tests.ipv6.extensions.test_linklayer_id
   dhcpkit.tests.ipv6.extensions.test_map
   dhcpkit.tests.ipv6.extensions.test_ntp
   dhcpkit.tests.ipv6.extensions.test_pd_exclude
   dhcpkit.tests.ipv6.extensions.test_prefix_delegation
   dhcpkit.tests.ipv6.extensions.test_remote_id
   dhcpkit.tests.ipv6.extensions.test_sip_servers
   dhcpkit.tests.ipv6.extensions.test_sntp
   dhcpkit.tests.ipv6.extensions.test_sol_max_rt
   dhcpkit.tests.ipv6.extensions.test_subscriber_id
   dhcpkit.tests.ipv6.extensions.test_timezone

