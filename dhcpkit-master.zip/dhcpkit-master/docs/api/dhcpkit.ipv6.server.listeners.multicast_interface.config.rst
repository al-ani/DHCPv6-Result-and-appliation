dhcpkit\.ipv6\.server\.listeners\.multicast\_interface\.config module
=====================================================================

.. automodule:: dhcpkit.ipv6.server.listeners.multicast_interface.config
    :members:
    :undoc-members:
    :show-inheritance:
