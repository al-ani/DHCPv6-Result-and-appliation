dhcpkit\.ipv6\.extensions\.ntp\_suboption\_registry module
==========================================================

.. automodule:: dhcpkit.ipv6.extensions.ntp_suboption_registry
    :members:
    :undoc-members:
    :show-inheritance:
