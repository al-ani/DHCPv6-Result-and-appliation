dhcpkit\.ipv6 package
=====================

.. automodule:: dhcpkit.ipv6
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    dhcpkit.ipv6.client
    dhcpkit.ipv6.extensions
    dhcpkit.ipv6.server

Submodules
----------

.. toctree::

   dhcpkit.ipv6.duid_registry
   dhcpkit.ipv6.duids
   dhcpkit.ipv6.message_registry
   dhcpkit.ipv6.messages
   dhcpkit.ipv6.option_registry
   dhcpkit.ipv6.options
   dhcpkit.ipv6.utils

