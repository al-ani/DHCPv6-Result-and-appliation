dhcpkit\.ipv6\.message\_registry module
=======================================

.. automodule:: dhcpkit.ipv6.message_registry
    :members:
    :undoc-members:
    :show-inheritance:
