dhcpkit\.ipv6\.server\.extensions\.ntp\.config module
=====================================================

.. automodule:: dhcpkit.ipv6.server.extensions.ntp.config
    :members:
    :undoc-members:
    :show-inheritance:
