dhcpkit\.ipv6\.server\.extensions\.static\_assignments\.sqlite module
=====================================================================

.. automodule:: dhcpkit.ipv6.server.extensions.static_assignments.sqlite
    :members:
    :undoc-members:
    :show-inheritance:
