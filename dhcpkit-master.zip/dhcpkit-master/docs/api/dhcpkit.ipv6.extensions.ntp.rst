dhcpkit\.ipv6\.extensions\.ntp module
=====================================

.. automodule:: dhcpkit.ipv6.extensions.ntp
    :members:
    :undoc-members:
    :show-inheritance:
