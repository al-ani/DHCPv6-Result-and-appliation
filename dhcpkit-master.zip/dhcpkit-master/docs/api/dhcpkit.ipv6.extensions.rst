dhcpkit\.ipv6\.extensions package
=================================

.. automodule:: dhcpkit.ipv6.extensions
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   dhcpkit.ipv6.extensions.bulk_leasequery
   dhcpkit.ipv6.extensions.client_fqdn
   dhcpkit.ipv6.extensions.dns
   dhcpkit.ipv6.extensions.dslite
   dhcpkit.ipv6.extensions.leasequery
   dhcpkit.ipv6.extensions.linklayer_id
   dhcpkit.ipv6.extensions.map
   dhcpkit.ipv6.extensions.ntp
   dhcpkit.ipv6.extensions.ntp_suboption_registry
   dhcpkit.ipv6.extensions.pd_exclude
   dhcpkit.ipv6.extensions.prefix_delegation
   dhcpkit.ipv6.extensions.relay_echo_request
   dhcpkit.ipv6.extensions.remote_id
   dhcpkit.ipv6.extensions.sip_servers
   dhcpkit.ipv6.extensions.sntp
   dhcpkit.ipv6.extensions.sol_max_rt
   dhcpkit.ipv6.extensions.subscriber_id
   dhcpkit.ipv6.extensions.timezone

