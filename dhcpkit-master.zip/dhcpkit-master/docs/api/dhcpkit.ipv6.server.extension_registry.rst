dhcpkit\.ipv6\.server\.extension\_registry module
=================================================

.. automodule:: dhcpkit.ipv6.server.extension_registry
    :members:
    :undoc-members:
    :show-inheritance:
