dhcpkit\.ipv6\.server\.extensions\.static\_assignments package
==============================================================

.. automodule:: dhcpkit.ipv6.server.extensions.static_assignments
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   dhcpkit.ipv6.server.extensions.static_assignments.config
   dhcpkit.ipv6.server.extensions.static_assignments.csv
   dhcpkit.ipv6.server.extensions.static_assignments.sqlite

