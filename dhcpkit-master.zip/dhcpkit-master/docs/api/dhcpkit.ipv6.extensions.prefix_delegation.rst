dhcpkit\.ipv6\.extensions\.prefix\_delegation module
====================================================

.. automodule:: dhcpkit.ipv6.extensions.prefix_delegation
    :members:
    :undoc-members:
    :show-inheritance:
