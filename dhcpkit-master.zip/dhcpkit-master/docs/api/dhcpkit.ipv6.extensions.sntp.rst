dhcpkit\.ipv6\.extensions\.sntp module
======================================

.. automodule:: dhcpkit.ipv6.extensions.sntp
    :members:
    :undoc-members:
    :show-inheritance:
