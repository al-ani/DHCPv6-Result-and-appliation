dhcpkit\.tests\.test\_registry module
=====================================

.. automodule:: dhcpkit.tests.test_registry
    :members:
    :undoc-members:
    :show-inheritance:
