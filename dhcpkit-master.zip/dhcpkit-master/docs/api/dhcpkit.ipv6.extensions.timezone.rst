dhcpkit\.ipv6\.extensions\.timezone module
==========================================

.. automodule:: dhcpkit.ipv6.extensions.timezone
    :members:
    :undoc-members:
    :show-inheritance:
