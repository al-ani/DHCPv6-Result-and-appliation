dhcpkit\.ipv6\.extensions\.sol\_max\_rt module
==============================================

.. automodule:: dhcpkit.ipv6.extensions.sol_max_rt
    :members:
    :undoc-members:
    :show-inheritance:
