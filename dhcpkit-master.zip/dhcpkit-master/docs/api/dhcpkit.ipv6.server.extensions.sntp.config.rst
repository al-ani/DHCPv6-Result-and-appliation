dhcpkit\.ipv6\.server\.extensions\.sntp\.config module
======================================================

.. automodule:: dhcpkit.ipv6.server.extensions.sntp.config
    :members:
    :undoc-members:
    :show-inheritance:
