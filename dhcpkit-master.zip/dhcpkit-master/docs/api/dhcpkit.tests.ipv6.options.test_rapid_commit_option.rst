dhcpkit\.tests\.ipv6\.options\.test\_rapid\_commit\_option module
=================================================================

.. automodule:: dhcpkit.tests.ipv6.options.test_rapid_commit_option
    :members:
    :undoc-members:
    :show-inheritance:
