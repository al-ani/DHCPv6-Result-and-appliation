dhcpkit\.ipv6\.server\.extensions\.rate\_limit\.config module
=============================================================

.. automodule:: dhcpkit.ipv6.server.extensions.rate_limit.config
    :members:
    :undoc-members:
    :show-inheritance:
