dhcpkit\.ipv6\.extensions\.remote\_id module
============================================

.. automodule:: dhcpkit.ipv6.extensions.remote_id
    :members:
    :undoc-members:
    :show-inheritance:
