dhcpkit\.tests\.ipv6\.messages\.test\_confirm\_message module
=============================================================

.. automodule:: dhcpkit.tests.ipv6.messages.test_confirm_message
    :members:
    :undoc-members:
    :show-inheritance:
