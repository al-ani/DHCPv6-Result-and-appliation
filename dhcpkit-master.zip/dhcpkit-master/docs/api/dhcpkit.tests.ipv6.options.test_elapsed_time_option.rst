dhcpkit\.tests\.ipv6\.options\.test\_elapsed\_time\_option module
=================================================================

.. automodule:: dhcpkit.tests.ipv6.options.test_elapsed_time_option
    :members:
    :undoc-members:
    :show-inheritance:
