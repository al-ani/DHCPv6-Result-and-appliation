dhcpkit\.ipv6\.option\_registry module
======================================

.. automodule:: dhcpkit.ipv6.option_registry
    :members:
    :undoc-members:
    :show-inheritance:
