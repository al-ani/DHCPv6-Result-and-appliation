dhcpkit\.ipv6\.server\.extensions\.subscriber\_id\.config module
================================================================

.. automodule:: dhcpkit.ipv6.server.extensions.subscriber_id.config
    :members:
    :undoc-members:
    :show-inheritance:
