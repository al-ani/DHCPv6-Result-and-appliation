dhcpkit\.registry module
========================

.. automodule:: dhcpkit.registry
    :members:
    :undoc-members:
    :show-inheritance:
