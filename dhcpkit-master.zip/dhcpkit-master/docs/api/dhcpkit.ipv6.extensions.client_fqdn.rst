dhcpkit\.ipv6\.extensions\.client\_fqdn module
==============================================

.. automodule:: dhcpkit.ipv6.extensions.client_fqdn
    :members:
    :undoc-members:
    :show-inheritance:
