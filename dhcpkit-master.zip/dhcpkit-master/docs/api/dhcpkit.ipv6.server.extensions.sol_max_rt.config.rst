dhcpkit\.ipv6\.server\.extensions\.sol\_max\_rt\.config module
==============================================================

.. automodule:: dhcpkit.ipv6.server.extensions.sol_max_rt.config
    :members:
    :undoc-members:
    :show-inheritance:
